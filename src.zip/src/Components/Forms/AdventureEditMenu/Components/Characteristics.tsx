import React from "react";
import Stack from "@mui/material/Stack";
import Grid from "@mui/material/Grid";

import { Box } from "@mui/system";
import { List, Paper, styled } from "@mui/material";
import { TAdventureLot, TCharacteristic } from "../../../../types/provider";
import {
  Text,
  Variant,
} from "../../../BaseComponents/DisplayingComponents/Text";
import RowText from "../../../BaseComponents/Inputs/RowText";
import MultilineText from "../../../BaseComponents/Inputs/MultilineText";
import Amount from "../../../BaseComponents/Inputs/Amount";
import AppBar from "@mui/material/AppBar";
import BasicModal from "../../../BaseComponents/Modals/BasicModal";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import PlaylistAddIcon from "@mui/icons-material/PlaylistAdd";
import AddAPhoto from "@mui/icons-material/AddAPhoto";
export default function Characteristics({
  characteristics,
  setCharacteristics,
}: {
  characteristics?: TCharacteristic[];
  setCharacteristics: Function;
}) {
  function getSelect(value: string) {
    console.log(value);
  }
  function getAmount(value: number) {
    console.log(value);
  }
  function getPassword(value: string) {
    console.log(value);
  }
  function getMultiText(value: string) {
    console.log(value);
  }
  function getPhoneNumber(value: string) {
    console.log(value);
  }
  function getText(value: string) {
    console.log(value);
  }
  function getTime(value: string) {
    console.log(value);
  }
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#fff",
    ...theme.typography.body1,
    padding: theme.spacing(0.5),
    textAlign: "center",
    color: theme.palette.text.primary,
  }));
  return (
    <>
      <Stack spacing={1}>
        <Text {...{ variant: Variant.h5, text: "Характеристики" }} />
        {/* <Grid container justifyContent="center">
        <Text {...{ variant: Variant.body1, text: "Имя клиента" }} />
      </Grid> */}
        <RowText
          {...{
            label: "Название",
            defaultValue: "",
            getText,
          }}
        />
        <MultilineText
          {...{
            defaultValue: "",
            getText: getMultiText,
            label: "Описание",
          }}
        />
        <Amount
          {...{
            label: "Количество участников",
            // max: 8,
            min: 1,
            defaultValue: 0,
            getAmount,
          }}
        />
        <RowText
          {...{
            label: "Продолжительность",
            defaultValue: "",
            getText,
          }}
        />
        <Amount
          {...{
            label: "Цена",
            // max: 8,
            min: 0,
            defaultValue:0,
            getAmount,
          }}
        />
        {/* <PasswordInput {...{ label: "Введите пароль", getPassword }} /> */}
        {/* <SelectInput
        {...{ label: "Выберите характеристику", getSelect, options }}
      /> */}
        {/* <TimeWithMinute {...{ getTime, label: "Продолжительность" }} /> */}
        {/* <BasicButton {...{ btnText: "Подтвердить выбор", onClick: () => {} }} /> */}
      </Stack>

      <AppBar position="static" color="inherit">
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="stretch"
          spacing={1}
          sx={{ color: "#111" }}
        >
          <Button
            sx={{ color: "#616161" }}
            component="label"
            // onChange={addHandler}
            fullWidth
          >
            <PlaylistAddIcon />
          </Button>
          <Button
            sx={{ color: "#616161" }}
            fullWidth
            component="label"
            // onClick={deleteHandler}
          >
            <DeleteIcon />
          </Button>
        </Stack>
      </AppBar>
      <Box sx={{ bgcolor: "rgba(0, 0, 0, 0.12)" }}>
        <List dense sx={{ width: "100%" }}>
          <Stack spacing={0.6}>
            {characteristics &&
              characteristics.map(
                (characteristic: TCharacteristic, index: number) => {
                  return (
                    <Item key={index} elevation={1}>
                      <Stack spacing={1}>
                        <Text
                          {...{ variant: Variant.h5, text: "Характеристики" }}
                        />
                        {/* <Grid container justifyContent="center">
        <Text {...{ variant: Variant.body1, text: "Имя клиента" }} />
      </Grid> */}
                        <RowText
                          {...{
                            label: "Название",
                            defaultValue: characteristic.name,
                            getText,
                          }}
                        />
                        <MultilineText
                          {...{
                            defaultValue: characteristic.description,
                            getText: getMultiText,
                            label: "Описание",
                          }}
                        />
                        <Amount
                          {...{
                            label: "Количество участников",
                            // max: 8,
                            min: 1,
                            defaultValue: characteristic.slotAmount,
                            getAmount,
                          }}
                        />
                        <RowText
                          {...{
                            label: "Продолжительность",
                            defaultValue: characteristic.name,
                            getText,
                          }}
                        />
                        <Amount
                          {...{
                            label: "Цена",
                            // max: 8,
                            min: 0,
                            defaultValue: characteristic.price,
                            getAmount,
                          }}
                        />
                        {/* <PasswordInput {...{ label: "Введите пароль", getPassword }} /> */}
                        {/* <SelectInput
        {...{ label: "Выберите характеристику", getSelect, options }}
      /> */}
                        {/* <TimeWithMinute {...{ getTime, label: "Продолжительность" }} /> */}
                        {/* <BasicButton {...{ btnText: "Подтвердить выбор", onClick: () => {} }} /> */}
                      </Stack>
                    </Item>
                  );
                }
              )}
          </Stack>
        </List>
      </Box>
    </>
  );
}
